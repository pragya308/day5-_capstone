"""Look at what the RAG tool would return, WITHOUT any agent. Useful for tuning the
STRONG_MATCH / WEAK_MATCH distance thresholds in pragati/config.py.

    python inspect_kb.py "how many casual leave days do I get?"
"""
import sys

from pragati.kb import KnowledgeBase, format_results

q = " ".join(sys.argv[1:]) or "Which department or team is this policy related to?"
print(format_results(KnowledgeBase().search(q)))
